# Example Package

This is a simple example python package. 

Followed tutorial:
[packaging-projects tutorial](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
to setup and build.